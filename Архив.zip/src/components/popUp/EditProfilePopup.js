import React, { useState } from 'react'
import { Popup } from '../Popup'

const EditPlacePopup = ({ person, setPerson, setPopUpVisible}) => {
    const addPlaceHandler = (place) => {  
        const [key] = Object.keys(place) || person.name
        const [value] = Object.values(place) || person.info
        console.log(Object.values(place));
        
        setPerson({
            ...person,
            name: key,
            info: value
        })
        setPopUpVisible(false)

    }
    return (
        <Popup
            person={person}
            addPlaceHandler={addPlaceHandler}/>
    )
}

export default EditPlacePopup;