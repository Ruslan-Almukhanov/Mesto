import React, { useState } from 'react'
import { Popup } from '../Popup'

const AddPlacePopup = ({ dataItems, setPopUpVisible, setDataItems }) => {

    const addPlaceHandler = (place) => {                
        const [key] = Object.keys(place)
        const [value] = Object.values(place)
        console.log(key, value);
        
        const newPlace = {
            id: 5,
            title: key,
            url: value
        }
        setDataItems([...dataItems, newPlace])
        setPopUpVisible(false)
    }

    return (
        <Popup
            type="add_place"
            addPlaceHandler={addPlaceHandler}
        />
    )
}

export default AddPlacePopup;