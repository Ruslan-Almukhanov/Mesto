import React, { useContext } from 'react'
import { PopCloseContext } from './MainLayout'
import { useInput } from '../hooks/useInput'

export const Popup = ({ type, addPlaceHandler, person }) => {
    const closeModal = useContext(PopCloseContext)

    //change form by checking type
    const checkType = (arg1, arg2) => {
        return type === 'add_place' ? arg1 : arg2
    }
    const input = useInput(type)

    return (
        <div className="popup">
            <div className="popup__content">
                <img onClick={() => closeModal(false)}
                    className="popup__close" alt="" src={"close.svg"} />
                <h3 className="popup__title">{checkType('Новое место', 'Редактировать профиль')}</h3>
                <form onSubmit={(e) => {
                    e.preventDefault()
                    addPlaceHandler({ [input.place.name]: input.place.url })
                }
                }
                    className="popup__form">
                    <input
                        defaultValue={type === 'add_place' ? '' : person.name}
                        onChange={input.inputHandler}
                        className="popup__input"
                        placeholder={checkType('Название', 'Имя')}
                        name="name"
                        required />
                    <input
                        defaultValue={type === 'add_place' ? '' : person.info}
                        onChange={input.inputHandler}
                        className="popup__input"
                        name="url"
                        placeholder={checkType('Url', 'О себе')}
                        required />
                    <button type="submit" className="popup__button">{checkType('Добавить', 'Сохранить')}</button>
                </form>
            </div>
        </div>
    )
}