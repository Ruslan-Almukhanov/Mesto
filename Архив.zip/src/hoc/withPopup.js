import React from 'react'

const UpdatedComponent = (OriginalComponent) => {
    const NewComponent = () => {

        return <OriginalComponent />
    }
    return NewComponent
}

export default UpdatedComponent;
