import { useState } from 'react'

export function useInput(type) {
    const [place, setPlace] = useState({
        name: 'Luk Beson',
        url: ''
    })

    const inputHandler = (e) => {
        const name = e.target.name
        const value = e.target.value
        console.log(name, value);
        
        setPlace({ ...place, [name]: value })
    }

    return {
        place,
        inputHandler
    }
}

