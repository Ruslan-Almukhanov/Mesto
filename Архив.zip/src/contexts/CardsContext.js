import React, { createContext, useState, useEffect } from 'react'
// пакет, создающий уникальные id
import uuid from 'uuid'

export const CardListContext = createContext()

export default function CardListContextProvider(props) {



}